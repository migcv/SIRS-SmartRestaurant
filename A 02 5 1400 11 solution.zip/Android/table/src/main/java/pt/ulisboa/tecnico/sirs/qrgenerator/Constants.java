package pt.ulisboa.tecnico.sirs.qrgenerator;

/**
 * Created by Miguel on 09/12/2016.
 */

public class Constants {
    public static final String IP = "185.43.210.233";
}
