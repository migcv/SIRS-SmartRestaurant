# SIRS-SmartRestaurant

Required Platform:
Mobile phone with Android 6 or newer
Android Studio
Python3
Python-Crypto


Steps to run the project:

1) python3 paymentServer.py
2) python3 restaurantServer.py
3) deploy APP to Android with sdk 24
4) deploy TABLE to emulator with sdk 24

Note: The python files are located in a private server, so in order to run the program the   IP addresses have to be changed to the new corresponding address and the ports being used are 10000-10004.
